@extends('layout')
@section('title', 'Exam Portal | Dashboard')
@section('content')

<style>
    @import "https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700";

    body {
        font-family: 'Poppins', sans-serif;
        background: #fafafa;
    }

    p {
        font-family: 'Poppins', sans-serif;
        font-size: 1.1em;
        font-weight: 300;
        line-height: 1.7em;
        color: #999;
    }

    a,
    a:hover,
    a:focus {
        color: inherit;
        text-decoration: none;
        transition: all 0.3s;
    }

    .navbar {
        padding: 15px 10px;
        background: #fff;
        border: none;
        border-radius: 0;
        margin-bottom: 40px;
        box-shadow: 1px 1px 3px rgba(0, 0, 0, 0.1);
    }

    .navbar-btn {
        box-shadow: none;
        outline: none !important;
        border: none;
    }

    .line {
        width: 100%;
        height: 1px;
        border-bottom: 1px dashed #ddd;
        margin: 40px 0;
    }

    /* ---------------------------------------------------
    SIDEBAR STYLE
----------------------------------------------------- */

    .wrapper {
        display: flex;
        width: 100%;
        align-items: stretch;
    }

    #sidebar {
        min-width: 250px;
        max-width: 250px;
        background: #7386D5;
        color: #fff;
        transition: all 0.3s;
    }

    #sidebar.active {
        margin-left: -250px;
    }

    #sidebar .sidebar-header {
        padding: 20px;
        background: #6d7fcc;
    }

    #sidebar ul.components {
        padding: 20px 0;
        border-bottom: 1px solid #47748b;
    }

    #sidebar ul p {
        color: #fff;
        padding: 10px;
    }

    #sidebar ul li a {
        padding: 10px;
        font-size: 1.1em;
        display: block;
    }

    #sidebar ul li a:hover {
        color: #7386D5;
        background: #fff;
    }

    #sidebar ul li.active>a,
    a[aria-expanded="true"] {
        color: #fff;
        background: #6d7fcc;
    }

    a[data-toggle="collapse"] {
        position: relative;
    }

    .dropdown-toggle::after {
        display: block;
        position: absolute;
        top: 50%;
        right: 20px;
        transform: translateY(-50%);
    }

    ul ul a {
        font-size: 0.9em !important;
        padding-left: 30px !important;
        background: #6d7fcc;
    }

    ul.CTAs {
        padding: 20px;
    }

    ul.CTAs a {
        text-align: center;
        font-size: 0.9em !important;
        display: block;
        border-radius: 5px;
        margin-bottom: 5px;
    }

    a.download {
        background: #fff;
        color: #7386D5;
    }

    a.article,
    a.article:hover {
        background: #6d7fcc !important;
        color: #fff !important;
    }

    /* ---------------------------------------------------
    CONTENT STYLE
----------------------------------------------------- */

    #content {
        width: 100%;
        padding: 20px;
        min-height: 100vh;
        transition: all 0.3s;
    }

    /* ---------------------------------------------------
    MEDIAQUERIES
----------------------------------------------------- */

    @media (max-width: 768px) {
        #sidebar {
            margin-left: -250px;
        }

        #sidebar.active {
            margin-left: 0;
        }

        #sidebarCollapse span {
            display: none;
        }
    }
</style>

<div class="wrapper">
    <!-- Sidebar  -->
    <nav id="sidebar">
        <div class="sidebar-header">
            <h3><a href="/dashboard">{{ __('Dashboard') }}</a></h3>
        </div>

        <ul class="list-unstyled components">
            <!-- <p>Dummy Heading</p> -->
            <!-- <li class="active">
                    <a href="#homeSubmenu" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle">Home</a>
                    <ul class="collapse list-unstyled" id="homeSubmenu">
                        <li>
                            <a href="#">Home 1</a>
                        </li>
                        <li>
                            <a href="#">Home 2</a>
                        </li>
                        <li>
                            <a href="#">Home 3</a>
                        </li>
                    </ul>
                </li> -->
            <!-- <li>
                    <a href="#">About</a>
                </li> -->
            <!-- <li>
                    <a href="#pageSubmenu" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle">Pages</a>
                    <ul class="collapse list-unstyled" id="pageSubmenu">
                        <li>
                            <a href="#">Page 1</a>
                        </li>
                        <li>
                            <a href="#">Page 2</a>
                        </li>
                        <li>
                            <a href="#">Page 3</a>
                        </li>
                    </ul>
                </li> -->
            <li>
                <a href="/questions">Questions</a>
            </li>
            <li>
                <a href="/admin/students">Students</a>
            </li>
            <li>
                <a href="/admin/contacts">Contacts</a>
            </li>
        </ul>
    </nav>

    <!-- Page Content  -->
    <div id="content">

        <nav class="navbar navbar-expand-lg navbar-light bg-light">
            <div class="container-fluid">

                <button type="button" id="sidebarCollapse" class="btn btn-info">
                    <i class="fas fa-align-left"></i>
                    <span>Toggle Sidebar</span>
                </button>
                <button class="btn btn-dark d-inline-block d-lg-none ml-auto" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <i class="fas fa-align-justify"></i>
                </button>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="nav navbar-nav ml-auto">
                    <button data-toggle="modal" data-target="#Modal_add" class="btn btn-primary"> Add </button>&emsp;
                    <li class="nav-item active">
                            <a class=" btn btn-success" href="/import_questions">Import Data</a>
                        </li>&emsp;
                        <li class="nav-item active">
                            <a class=" btn btn-warning" href="\exportQuestionsRecord">Export Data</a>
                        </li>
                        <!-- <li class="nav-item">
                            <a class="nav-link" href="#">Page</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#">Page</a>
                        </li> -->
                    </ul>
                </div>
            </div>
        </nav>
        @if (session('success'))
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            {{ session('success') }}
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
        @endif

        @if (session('error'))
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            {{ session('error') }}
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
        @endif

        <div class="container">
            <h2>Manage questions</h2>
            <!-- <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Aliquam, temporibus.</p> -->

            <table class="table table-striped table-hover table-bordered">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Question <i class="fa fa-sort"></i></th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($questions as $q)
                    <tr>
                        <td>{{$q->id}}</td>
                        <td>{{$q->question}}</td>
                        <td>
                            <a href="#" class="text-warning" data-toggle="modal" data-target="#Modal_update{{$q->id}}">Update</a>&emsp;
                            <a href="#" class="text-danger" data-toggle="modal" data-target="#Modal_delete{{$q->id}}">Delete</a>
                        </td>
                    </tr>


                    <!-- Modal-delete -->
                    <div class="modal fade" id="Modal_delete{{$q->id}}" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <div class="modal-dialog" role="document">
                            <div class="modal-content">
                                <form method="post" action="/delete">
                                    {{ csrf_field() }}
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="exampleModalLabel">Delete</h5>
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                        </button>
                                    </div>
                                    <div class="modal-body">
                                        <input style="visibility: hidden" name="id" value="{{$q->id}}">
                                        <p>{{$q->question}}</p>
                                        <h5>Are you sure you want to delete?</h5>

                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                                            <button type="submit" class="btn btn-danger">Delete Questions</button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>

                    <!-- Modal-update -->
                    <div class="modal fade" id="Modal_update{{$q->id}}" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <div class="modal-dialog" role="document">
                            <div class="modal-content">
                                <form method="post" action="/update">
                                    {{ csrf_field() }}
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="exampleModalLabel">Update</h5>
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                        </button>
                                    </div>
                                    <div class="modal-body">
                                        <div class="row">
                                            <h5>Question: </h5>
                                        </div>
                                        <input style="visibility: hidden" name="id" value="{{$q->id}}">
                                        <div class="row" style="padding:10px;">
                                            <input name="question" value="{{$q->question}}" class="form-control">
                                        </div>
                                        <div class="row">
                                            <div class="col-md-6"><label>A:</label></div>
                                            <div class="col-md-6"><label>B:</label></div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-6"><input value="{{$q->a}}" name="opa"></div>
                                            <div class="col-md-6"><input value="{{$q->b}}" name="opb"></div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-6"><label>C:</label></div>
                                            <div class="col-md-6"><label>D:</label></div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-6"><input value="{{$q->c}}" name="opc"></div>
                                            <div class="col-md-6"><input value="{{$q->d}}" name="opd"></div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-3"><label>Answer: </label>
                                                <select name="ans" class="form-control">
                                                    <option value="{{$q->ans}}">{{$q->ans}}</option>
                                                    <option value="A">A</option>
                                                    <option value="B">B</option>
                                                    <option value="C">C</option>
                                                    <option value="D">D</option>
                                                </select>
                                            </div>
                                            <div class="col-md-9"></div>

                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                                <button type="submit" class="btn btn-primary">Update Questions</button>
                                            </div>
                                </form>
                            </div>
                        </div>
                    </div>
                    @endforeach
                    
                    
                    

                </tbody>
            </table>
            <div>
            
                {{$questions->links("pagination::bootstrap-4")}}
            </div>

        </div>
    </div>
</div>




<!-- Modal-Add -->
<div class="modal fade" id="Modal_add" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <form method="post" action="/add">
                @csrf
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Add</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <h5>Question: </h5>
                    </div>
                    <div class="row" style="padding:10px;">
                        <input name="question" class="form-control">
                    </div>
                    <div class="row">
                        <div class="col-md-6"><label>A:</label></div>
                        <div class="col-md-6"><label>B:</label></div>
                    </div>
                    <div class="row">
                        <div class="col-md-6"><input name="opa"></div>
                        <div class="col-md-6"><input name="opb"></div>
                    </div>
                    <div class="row">
                        <div class="col-md-6"><label>C:</label></div>
                        <div class="col-md-6"><label>D:</label></div>
                    </div>
                    <div class="row">
                        <div class="col-md-6"><input name="opc"></div>
                        <div class="col-md-6"><input name="opd"></div>
                    </div>
                    <div class="row">
                        <div class="col-md-3"><label>Answer: </label>
                            <select name="ans" class="form-control">
                                <option value="A">A</option>
                                <option value="B">B</option>
                                <option value="C">C</option>
                                <option value="D">D</option>
                            </select>
                        </div>
                        <div class="col-md-9"></div>

                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-primary">Add Questions</button>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>


@endsection