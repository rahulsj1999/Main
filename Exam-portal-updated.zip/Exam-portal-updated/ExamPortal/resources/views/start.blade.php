@extends('layout')
@section('title', 'Exam Portal | Questions')
@section('content')

@if (session('success'))

<div class="alert alert-success alert-dismissible fade show" role="alert">
    {{ session('success') }}
    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">&times;</span>
    </button>
</div>
@endif

@foreach($data as $d)

<!-- <p></p> -->
@endforeach

<div class="container mt-4">

    <div class="jumbotron" >
        <p class="text-secondary " style="font-size: 16px;  font-weight: 600; text-transform: uppercase;">Enroll No:&nbsp; {{$d->enrollno}}</p>
        <p class="text-secondary " style="font-size: 16px;  font-weight: 600; text-transform: uppercase;">Name:&nbsp; {{$d->name}}</p>
        <p class="text-secondary " style="font-size: 16px;  font-weight: 600; text-transform: uppercase;">Course:&nbsp; {{$d->course_name}}</p>
        <p class="text-secondary" style="font-size: 16px; font-weight: 600;text-transform: uppercase; ">Mobile No:&nbsp; {{$d->mobileno}}</p>
        <p class="text-secondary" style="font-size: 16px; font-weight: 600;text-transform: uppercase; ">Semester:&nbsp; {{$d->semester}}</p>
        <p class="text-secondary" style="font-size: 16px; font-weight: 600;text-transform: uppercase; ">Seat No:&nbsp; {{$d->division}}{{$d->rollno}}</p>
    </div>
    <h2>Are you Ready?</h2>
    <p style="font-family: raleway;">Good luck!</p>
    <div style="text-align: right" >
    <a href="/startexam" class="btn btn-primary" role="button">Start Exam</a>
    </div>
</div>


@endsection