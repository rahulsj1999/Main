@extends('layout')
@section('title', 'Exam Portal | Contact')
@section('content')

<div class="container py-4">
    <h3>Contact us</h3>
    @if (session('success'))
        <div class="alert alert-success alert-dismissible">
        <button type="button" class="close" data-dismiss="alert">&times;</button>
            {{ session('success') }}
        </div>
    @endif
    <form id="contactForm" action="/show" method="post">
        {{ csrf_field() }}
        <!-- Name input -->
        <div class="mb-3">
            <label class="form-label" for="name">Name</label>
            <input class="form-control" id="name" type="text" placeholder="Name" value="{{ old('name') }}" name="name" data-sb-validations="required" />
            @if ($errors->has('name'))
                                      <span class="text-danger">{{ $errors->first('name') }}</span>
                                  @endif
        </div>
        

        <!-- Email address input -->
        <div class="mb-3">
            <label class="form-label" for="emailAddress">Email Address</label>
            <input class="form-control" id="emailAddress" type="email" name="email" value="{{ old('email') }}" placeholder="Email Address" data-sb-validations="required, email" />

            @if ($errors->has('email'))
                                          <span class="text-danger">{{ $errors->first('email') }}</span>
                                      @endif
        </div>

        <!-- Message input -->
        <div class="mb-3">
            <label class="form-label" for="message">Message</label>
            <textarea class="form-control" id="message" name='message' type="text" value="{{ old('message') }}" placeholder="Message" style="height: 10rem;" data-sb-validations="required"></textarea>

            @if ($errors->has('message'))
                                          <span class="text-danger">{{ $errors->first('message') }}</span>
                                      @endif
        </div>

        <!-- Form submit button -->
        <div class="d-grid">
            <button class="btn btn-primary btn-lg" type="submit">Submit</button>
        </div>

    </form>

</div>
@endsection