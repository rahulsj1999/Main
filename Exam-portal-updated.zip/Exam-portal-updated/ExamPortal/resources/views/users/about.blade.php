@extends('layout')
@section('title', 'Exam Portal | About')
@section('content')
<style>
    p {
        font-size: 15px;
        line-height: 1.7;
        letter-spacing: 0.3px;
    }
    </style>
    <div class="container mt-4 mb-4" >
        <h3>About</h3>
        <hr>
        <p>
        ExamPortal is a brand owned by  L J University, is a fully integrated platform for providing end to end online computer based examination services from students registration to result processing. With over 12 years of experience in the assessment and examination industry, our focus has been on delivering cost effective, secure and efficient examination and assessment services for our students.

<br><br>We have developed our services in close collaboration with some of the leading educational institutions and businesses in India and internationally.
            
<br><br> LJ Group of Institutes is managed by Lok Jagruti Kendra (LJK), a Charitable Trust and a Registered Society established in1980 by eminent academicians and 
            visionaries like Prof. B.M. Peerzada, former Dean of Commerce Faculty,Gujarat University, Padma Bhushan Lord Meghnad Desai (L ondon School of Economics ),
             Prof. Gautam Appa (LSE), Late Prof. M.S. Trivedi, former Vice Chancellor, South Gujarat University, renowned jurist Late Shri Girishbhai Patel and Shri Subodhbhai Shah. 
             It was envisioned as “a key player in education and social development by promoting and nurturing creativity, scholarship, innovation and excellence through a chain of quality institutes.” 
              LJK’s mission has been “to establish and manage institutions with an environment in which new ideas, delivery strategies and scholarship flourish and from where leaders and innovators of tomorrow shall emerge.” </p>
    </div>

@endsection
