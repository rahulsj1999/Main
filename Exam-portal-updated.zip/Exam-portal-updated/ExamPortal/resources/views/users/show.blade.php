@extends('layout')
@section('title', 'Exam Portal | Show')
@section('content')
    <!-- Main section -->
    <div class="container mt-4 mb-4">
        <h3>Message From User</h3>
        <p>Name = {{$_POST['name']}}</p>
        <p>Email = {{$_POST['email']}}</p>
        <p>Message = {{$_POST['message']}}</p>
    </div>

@endsection