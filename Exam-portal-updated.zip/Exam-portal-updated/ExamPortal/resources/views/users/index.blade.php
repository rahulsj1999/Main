@extends('layout')
@section('title', 'Exam Portal | Home')
@section('content')

<div class="container my-5">
    
    @if (session('success'))
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            {{ session('success') }}
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
        @endif

        @if (session('error'))
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            {{ session('error') }}
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
        @endif
    <div class="row">
        <div class="col-lg-1">

        </div>
        <div class="col-lg-4">
            <a href="/studentlogin" class="btn btn-link">
                <div class="card" style="width: 24rem;">
                    <img class="card-img-top" src="{{url('images/img127.jpg')}}" alt="Card image cap">
                    <ul class="list-group list-group-flush">
                        <li class="list-group-item">Student Login</li>
                    </ul>
                </div>
            </a>
        </div>
        
        <div class="col-lg-1"></div>
        <div class="col-lg-4">
            <a href="/login" class="btn btn-link">
                <div class="card" style="width: 24rem;">
                    <img class="card-img-top" src="{{url('images/img126.jpg')}}" alt="Card image cap">

                    <ul class="list-group list-group-flush">
                        <li class="list-group-item">Admin Login</li>
                    </ul>
                </div>
            </a>
        </div>
        <div class="col-lg-2">

        </div>
    </div>

</div>
@endsection

