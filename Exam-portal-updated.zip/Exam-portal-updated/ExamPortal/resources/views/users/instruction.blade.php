@extends('layout')
@section('title', 'Exam Protal | Dashboard')
@section('content')





<div class="instruct px-5 py-5">

    <h4><b>General instruction:</b></h4><br>
    <form action="">
        <input type="radio" required> online<br><br>
    </form>
    <h5>Read the Instruction Carefully:</h5>
    <ol>
        <li> Do not resize or minimise the browser during the online exam..</li>
        <li> Do not close the browser during the test before your exam is complete..</li>
        <li> Do not click the ‘BACK’ button of browser during exam..</li>
        <li> Keep an eye on the TIMER CLOCK on top left of the online exam page of the browser to keep a track of
            the time left..</li>
        <li> Do not leave the online exam browser page IDLE for more than 5 minutes to prevent the system from
            logging you out automatically. Keep moving the cursor (for laptop/desktop) or touch the screen (from
            mobile) frequently during the exam..</li>
        <li>After finishing the exam, click on the PRE-CONFIRM button at the bottom of the browser page.</li>
        <li> On the window that pops up on clicking the pre-confirm button, cross check your ‘admission number’ and
            the total number of questions attempted..</li>
        <li>If the number of questions attempted shown is not correct, press on CANCEL to go back to the main
            question paper and check for any anomaly..</li>
        <li>If the number of questions attempted shown is correct, click the checkbox ‘Match as per attempted’ and
            click the ‘SUBMIT’ button..</li>
        <li> Once submitted, a message shall be displayed “Your Exam has been submitted successfully’ and you
            can logout from the student online portal..</li>

        <li>Make sure you appear for the online exam sitting alone in a well lit room with no background noise during
            the entire process of the exam.</li>
        <li> For subjects that requires rough work, make sure you do the rough works on blank sheet and not on any
            notebook..</li>
        <li> If any student is found to use unfair means or if the student is not visible on camera during the entire
            course of the online exam, that student’s exam will be disqualified .</li>
    </ol>
    <br>
    <div class="d-flex" style="justify-content: space-between;">
    <div><input type="checkbox" id="check" name="accept" style="height: 24px; width:20px; ">&nbsp;&nbsp;<span style="margin-bottom: -10px">I accept the terms and conditions.</span></div>
    

    <div class="strExam"><input type="button" value="START" name="start" class="btn btn-primary btn-sm"></div>
    </div>
  <br>
</div>
@endsection