@extends('layout')
@section('title', 'Exam Protal | Questions')
@section('content')

<div class="container mt-3">

    <form action="\uploadQuestionsRecord" method="post" enctype="multipart/form-data">
        {{csrf_field()}}
        <p><input type="file" name="file" id="" class="form-control"></p>
        <p><input type="submit" value="Submit" class="btn btn-info"></p>
    </form>
</div>
@endsection