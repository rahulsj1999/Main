
<!doctype html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">


    <link href="{{url('css/bootstrap.css')}}" rel="stylesheet">
    <link href="{{url('css/styles.css')}}" rel="stylesheet">


    <title>@yield('title')</title>
</head>

<body>

<nav class="navbar navbar-expand-lg bg-dark navbar-dark navbar-laravel mb-0">
    <div class="container">
        <a class="navbar-brand" href="/"><img src="{{url('images/logo.png')}}" height="55px" width="210"></a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
   
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav ml-auto">
                @guest
                    <li class="nav-item">
                        <a class="nav-link" href="/about">About</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="/contact">Contact</a>
                    </li>
                    <!-- <li class="nav-item">
                        <a class="nav-link" href="/instruction">Instruction</a>
                    </li> -->
                    
                    
                @else
                    <li class="nav-item">
                        <a class="nav-link" href="{{ route('logout') }}">Logout</a>
                    </li>
                @endguest
            </ul>
  
        </div>
    </div>
</nav>
  
@yield('content')

<!-- Footer Section -->
<footer id="footer" class="bg-dark text-center mt-4" style="z-index: 100;">
            <span style="font-family: Raleway;">Copyright ©2022 — ExamPortal</span>
</footer>
     <script src="{{url('js/jquery.js')}}"></script>
     <script src="{{url('js/popper.js')}}"></script>
     <script src="{{url('js/bootstrap.js')}}"></script>
     <script>

    $(document).ready(function () {
        $('#sidebarCollapse').on('click', function () {
            $('#sidebar').toggleClass('active');
        });
    });
</script>
</body>
</html>