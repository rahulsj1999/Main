<link href="files/bootstrap.min.css" rel="stylesheet" type="text/css">
<link href="files/my.css" rel="stylesheet" type="text/css">

<div class="container my-5">
    <br><br><br><br>
    <div class="row">
        <div class="col-lg-1">

        </div>
        <div class="col-lg-4">
            <a href="/start" class="btn btn-link">
                <div class="card" style="width: 28rem;">
                    <img class="card-img-top" src="<?php echo e(url('images/img127.jpg')); ?>" alt="Card image cap">
                    <ul class="list-group list-group-flush">
                        <li class="list-group-item">Student Login</li>
                    </ul>
                </div>
            </a> 
        </div>
        
        <div class="col-lg-1"></div>
        <div class="col-lg-4">
            <a href="/questions" class="btn btn-link">
                <div class="card" style="width: 28rem;">
                    <img class="card-img-top" src="<?php echo e(url('images/img126.jpg')); ?>" alt="Card image cap">

                    <ul class="list-group list-group-flush">
                        <li class="list-group-item">Admin Login</li>

                    </ul>
                </div>
            </a>
        </div>
        <div class="col-lg-2">

        </div>
    </div>

</div>



<script scr="files/jquery.min.js"></script>
<script scr="files/popperjs.min.js"></script>
<script scr="files/bootstrap.min.js"></script><?php /**PATH C:\wamp64\www\ExamPortal\resources\views/welcome.blade.php ENDPATH**/ ?>