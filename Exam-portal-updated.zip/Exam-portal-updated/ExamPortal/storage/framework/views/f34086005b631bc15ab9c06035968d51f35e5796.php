<link href="files/bootstrap.min.css" rel="stylesheet" type="text/css">
<link href="files/my.css" rel="stylesheet" type="text/css">

<div class="back2">

<div class="container-field">
    <div class="row">
    <div class="col-md-3"></div>
    <div class="col-md-4"></div>
    <div class="col-md-5"></div>

</div>

</div>

<script scr="files/jquery.min.js"></script>
<script scr="files/popperjs.min.js"></script>
<script scr="files/bootstrap.min.js"></script><?php /**PATH C:\wamp64\www\ExamPortalmain\resources\views/answerdesk.blade.php ENDPATH**/ ?>