
<?php $__env->startSection('title', 'Exam Protal | Students'); ?>
<?php $__env->startSection('content'); ?>

<div class="container mt-3">

    <form action="\uploadStudentsRecord" method="post" enctype="multipart/form-data">
        <?php echo e(csrf_field()); ?>

        <p><input type="file" name="file" id="" class="form-control"></p>
        <p><input type="submit" value="Submit" class="btn btn-info"></p>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\ExamPortal\resources\views/data_uploads/importstudentrecords.blade.php ENDPATH**/ ?>