<link href="files/bootstrap.min.css" rel="stylesheet" type="text/css">

<div class="container-fluid">
  <br>
  <br>
  <br>
  <br>
  <br>
  <br>
  <br>
  <br>

    <div class="row">
        <div class="col-md-5">
        </div>
        <div class="col-md-4">
            <h3>Are you ready?</h3>
            <br>
            <a href="startexam"><button class="btn btn-primary" style="margin-left:10%;">Start Exam</button></a>
            <div class="text-center"><a href="/">Home?</a></div>
        </div>
        <div class="col-md-3">
        </div>
</div>
</div>







<script scr="files/jquery.min.js"></script>
<script scr="files/popperjs.min.js"></script>
<script scr="files/bootstrap.min.js"></script><?php /**PATH C:\wamp64\www\ExamPortalmain\resources\views/start.blade.php ENDPATH**/ ?>