
<?php $__env->startSection('title', 'Exam Portal | Questions'); ?>
<?php $__env->startSection('content'); ?>

<?php if(session('success')): ?>

<div class="alert alert-success alert-dismissible fade show" role="alert">
    <?php echo e(session('success')); ?>

    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">&times;</span>
    </button>
</div>
<?php endif; ?>

<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<!-- <p></p> -->
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<div class="container mt-4">

    <div class="jumbotron" >
        <p class="text-secondary " style="font-size: 16px;  font-weight: 600; text-transform: uppercase;">Enroll No:&nbsp; <?php echo e($d->enrollno); ?></p>
        <p class="text-secondary " style="font-size: 16px;  font-weight: 600; text-transform: uppercase;">Name:&nbsp; <?php echo e($d->name); ?></p>
        <p class="text-secondary " style="font-size: 16px;  font-weight: 600; text-transform: uppercase;">Course:&nbsp; <?php echo e($d->course_name); ?></p>
        <p class="text-secondary" style="font-size: 16px; font-weight: 600;text-transform: uppercase; ">Mobile No:&nbsp; <?php echo e($d->mobileno); ?></p>
        <p class="text-secondary" style="font-size: 16px; font-weight: 600;text-transform: uppercase; ">Semester:&nbsp; <?php echo e($d->semester); ?></p>
        <p class="text-secondary" style="font-size: 16px; font-weight: 600;text-transform: uppercase; ">Seat No:&nbsp; <?php echo e($d->division); ?><?php echo e($d->rollno); ?></p>
    </div>
    <h2>Are you Ready?</h2>
    <p style="font-family: raleway;">Good luck!</p>
    <div style="text-align: right" >
    <a href="/startexam" class="btn btn-primary" role="button">Start Exam</a>
    </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\ExamPortal\resources\views/start.blade.php ENDPATH**/ ?>