
<?php $__env->startSection('title', 'Exam Protal | Questions'); ?>
<?php $__env->startSection('content'); ?>

<style>
    input[type="radio"] {
    -ms-transform: scale(1.5); /* IE 9 */
    -webkit-transform: scale(1.5); /* Chrome, Safari, Opera */
    transform: scale(1.5);
}
</style>
<script>
    document.addEventListener('contextmenu', (event) => event.preventDefault());
    
</script>

<div class="container-field">
    <form method="post" action="/submitans">
        <?php echo e(csrf_field()); ?>

        <div class="row" style="padding-top: 100px;">
            <div class="col-md-3"></div>
            <div class="col-md-4" style="font-size: 18px;">
                <h4>#<?php echo e(Session::get("nextq")); ?> : <?php echo e($question->question); ?></h4><br>
                <input value="A" name="ans" type="radio" required> &emsp;(A)<span> <?php echo e($question->a); ?></span><br>
                <input value="B" name="ans" type="radio" required> &emsp;(B)<span> <?php echo e($question->b); ?></span><br>
                <input value="C" name="ans" type="radio" required>&emsp; (C)<span> <?php echo e($question->c); ?></span><br>
                <input value="D" name="ans" type="radio" required>&emsp; (D)<span> <?php echo e($question->d); ?></span><br>
                <input value="<?php echo e($question->ans); ?>" style="visibility:hidden" name="dbans">
                <br>
                <button type="submit" class="btn btn-primary">Next &rightarrow;</button>
            </div>

            


    </form>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\ExamPortal\resources\views/answerdesk.blade.php ENDPATH**/ ?>