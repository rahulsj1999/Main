
<?php $__env->startSection('title', 'Exam Portal | Show'); ?>
<?php $__env->startSection('content'); ?>
    <!-- Main section -->
    <div class="container mt-4 mb-4">
        <h3>Message From User</h3>
        <p>Name = <?php echo e($_POST['name']); ?></p>
        <p>Email = <?php echo e($_POST['email']); ?></p>
        <p>Message = <?php echo e($_POST['message']); ?></p>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\ExamPortal\resources\views/users/show.blade.php ENDPATH**/ ?>