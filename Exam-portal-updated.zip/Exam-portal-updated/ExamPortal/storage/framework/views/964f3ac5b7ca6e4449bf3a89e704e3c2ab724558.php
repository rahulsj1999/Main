
<!doctype html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">


    <link href="<?php echo e(url('css/bootstrap.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(url('css/fontawesome.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(url('css/styles.css')); ?>" rel="stylesheet">

    <!-- <title>Exam Portal | Home</title> -->
    <title><?php echo $__env->yieldContent('title'); ?></title>
</head>

<body>

<nav class="navbar navbar-expand-lg bg-dark navbar-dark navbar-laravel">
    <div class="container">
        <a class="navbar-brand" href="/">ExamPortal</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
   
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav ml-auto">
                <?php if(auth()->guard()->guest()): ?>
                    <li class="nav-item">
                        <a class="nav-link" href="/about">About</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="/contact">Contact</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="/instruction">Instruction</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('login')); ?>">Login</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('register')); ?>">Register</a>
                    </li>
                    
                <?php else: ?>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('logout')); ?>">Logout</a>
                    </li>
                <?php endif; ?>
            </ul>
  
        </div>
    </div>
</nav>
  
<?php echo $__env->yieldContent('content'); ?>

<!-- Footer Section -->
<footer id="footer" class="bg-dark text-center">
            <span style="font-family: Raleway;">Copyright ©2022 — ExamPortal</span>
</footer>
     
</body>
</html><?php /**PATH C:\wamp64\www\ExamPortalmain\resources\views/layout.blade.php ENDPATH**/ ?>