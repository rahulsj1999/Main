
<?php $__env->startSection('title', 'Exam Protal | Questions'); ?>
<?php $__env->startSection('content'); ?>

<div class="container">
  <h3 class="my-5 text-secondary">Exam Status</h3>

  <table class="table table-bordered">
    <thead>
      <tr>
        <!-- <th scope="col">Total Questions</th> -->
        <th scope="col">Correct</th>
        <th scope="col">Incorrect</th>
        <th scope="col">Result</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <!-- <th scope="row">1</th> -->
        <td><?php echo e(Session::get('correctans')); ?></td>
        <td><?php echo e(Session::get('wrongans')); ?></td>
        <td> <?php echo e(Session::get('correctans')); ?>/ <?php echo e(Session::get('correctans') + Session::get('wrongans')); ?></td>
      </tr>

    </tbody>
  </table>
  <a href="/" class="btn btn-primary">Finish Exam</a>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\ExamPortal\resources\views/end.blade.php ENDPATH**/ ?>