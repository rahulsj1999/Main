<!-- Footer Section -->
<footer id="footer" class="text-center">
        <span>Made with ❤️ by Dipesh, Rahul, Mukesh</span>
</footer><?php /**PATH C:\wamp64\www\ExamPortal\resources\views/\user_layouts/footer.blade.php ENDPATH**/ ?>