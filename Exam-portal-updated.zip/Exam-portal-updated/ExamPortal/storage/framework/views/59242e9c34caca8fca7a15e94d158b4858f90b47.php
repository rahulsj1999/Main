
<?php $__env->startSection('title', 'Exam Protal | ImageDemo'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container mb-5">
        <h3>Upload File</h3>
        <form action="#" method="post" enctype="multipart/form-data">
        Upload file: <input type="file" name="file" id="" class="form-control"><br>
        <input type="submit" value="Submit" class="btn btn-info btn-sm">
        </form>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\ExamPortal\resources\views/image_demo.blade.php ENDPATH**/ ?>