
<?php $__env->startSection('title', 'Exam Portal | Home'); ?>
<?php $__env->startSection('content'); ?>

<div class="container my-5">
    <br><br><br>
    <div class="row">
        <div class="col-lg-1">

        </div>
        <div class="col-lg-4">
            <a href="/studentlogin" class="btn btn-link">
                <div class="card" style="width: 24rem;">
                    <img class="card-img-top" src="<?php echo e(url('images/img127.jpg')); ?>" alt="Card image cap">
                    <ul class="list-group list-group-flush">
                        <li class="list-group-item">Student Login</li>
                    </ul>
                </div>
            </a>
        </div>
        
        <div class="col-lg-1"></div>
        <div class="col-lg-4">
            <a href="/login" class="btn btn-link">
                <div class="card" style="width: 24rem;">
                    <img class="card-img-top" src="<?php echo e(url('images/img126.jpg')); ?>" alt="Card image cap">

                    <ul class="list-group list-group-flush">
                        <li class="list-group-item">Admin Login</li>
                    </ul>
                </div>
            </a>
        </div>
        <div class="col-lg-2">

        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>

<!-- Route::get('/home', [democontroller::class, 'funcname']) -->
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\ExamPortalmain\resources\views/users/index.blade.php ENDPATH**/ ?>