
<?php $__env->startSection('title', 'Exam Protal | Questions'); ?>
<?php $__env->startSection('content'); ?>


<div class="container-fluid">
  <div class="row">
    <div class="col-md-4"></div>
    <div class="col-md-4">
      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <strong>Error!</strong> <?php echo e($error); ?>

        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

      <?php if(Session::get('SuccessMessage')): ?>
      <div class="alert alert-success alert-dismissible fade show" role="alert">
        <strong>Success!</strong> <?php echo e(Session::get('SuccessMessage')); ?>

        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>

      <?php Session::forget('SuccessMessage'); ?>
      <?php endif; ?>

    </div>
    <div class="col-md-4"></div>
  </div>
  <div class="container-xl">
    <div class="table-responsive">
      <div class="table-wrapper">
        <div class="table-title">
          <div class="row">
            <div class="col-sm-1">
              <h2>Users <b></b></h2>
            </div>
            <div class="col-sm-7"><button data-toggle="modal" data-target="#Modal_add" class="btn btn-primary">Add</button><a href="/">Home?</a></div>
            <div class="col-sm-4">
              <div class="search-box">

                <input type="text" class="form-control" placeholder="Search&hellip;">
              </div>
            </div>
          </div>
        </div>
        <table class="table table-striped table-hover table-bordered">
          <thead>
            <tr>
              <th>#</th>
              <th>Question <i class="fa fa-sort"></i></th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            <?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $q): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td><?php echo e($loop->index); ?></td>
              <td><?php echo e($q->question); ?></td>
              <td>
                <a href="#" class="text-warning" data-toggle="modal" data-target="#Modal_update<?php echo e($q->id); ?>">Update</a>
                <a href="#" class="text-danger" data-toggle="modal" data-target="#Modal_delete<?php echo e($q->id); ?>">Delete</a>
              </td>
            </tr>
            

            <!-- Modal-delete -->
            <div class="modal fade" id="Modal_delete<?php echo e($q->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
              <div class="modal-dialog" role="document">
                <div class="modal-content">
                  <form method="post" action="/delete">
                    <?php echo e(csrf_field()); ?>

                    <div class="modal-header">
                      <h5 class="modal-title" id="exampleModalLabel">Delete</h5>
                      <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                      </button>
                    </div>
                    <div class="modal-body">
                      <input style="visibility: hidden" name="id" value="<?php echo e($q->id); ?>">
                      <p><?php echo e($q->question); ?></p>
                      <h5>Are you sure you want to delete?</h5>

                      <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-danger">Delete Questions</button>
                      </div>
                    </div>
                  </form>
                </div>
              </div>
            </div>

            <!-- Modal-update -->
            <div class="modal fade" id="Modal_update<?php echo e($q->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
              <div class="modal-dialog" role="document">
                <div class="modal-content">
                  <form method="post" action="/update">
                    <?php echo e(csrf_field()); ?>

                    <div class="modal-header">
                      <h5 class="modal-title" id="exampleModalLabel">Update</h5>
                      <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                      </button>
                    </div>
                    <div class="modal-body">
                      <div class="row">
                        <h5>Question: </h5>
                      </div>
                      <input style="visibility: hidden" name="id" value="<?php echo e($q->id); ?>">
                      <div class="row" style="padding:10px;">
                        <input name="question" value="<?php echo e($q->question); ?>" class="form-control">
                      </div>
                      <div class="row">
                        <div class="col-md-6"><label>A:</label></div>
                        <div class="col-md-6"><label>B:</label></div>
                      </div>
                      <div class="row">
                        <div class="col-md-6"><input value="<?php echo e($q->a); ?>" name="opa"></div>
                        <div class="col-md-6"><input value="<?php echo e($q->b); ?>" name="opb"></div>
                      </div>
                      <div class="row">
                        <div class="col-md-6"><label>C:</label></div>
                        <div class="col-md-6"><label>D:</label></div>
                      </div>
                      <div class="row">
                        <div class="col-md-6"><input value="<?php echo e($q->c); ?>" name="opc"></div>
                        <div class="col-md-6"><input value="<?php echo e($q->d); ?>" name="opd"></div>
                      </div>
                      <div class="row">
                        <div class="col-md-3"><label>Answer: </label>
                          <select name="ans" class="form-control">
                            <option value="<?php echo e($q->ans); ?>"><?php echo e($q->ans); ?></option>
                            <option value="A">A</option>
                            <option value="B">B</option>
                            <option value="C">C</option>
                            <option value="D">D</option>
                          </select>
                        </div>
                        <div class="col-md-9"></div>

                        <div class="modal-footer">
                          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                          <button type="submit" class="btn btn-primary">Update Questions</button>
                        </div>
                  </form>
                </div>
              </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

          </tbody>
        </table>

      </div>
    </div>
  </div>



  <!-- Modal-Add -->
  <div class="modal fade" id="Modal_add" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <form method="post" action="/add">
          <?php echo csrf_field(); ?>
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Add</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="modal-body">
            <div class="row">
              <h5>Question: </h5>
            </div>
            <div class="row" style="padding:10px;">
              <input name="question" class="form-control">
            </div>
            <div class="row">
              <div class="col-md-6"><label>A:</label></div>
              <div class="col-md-6"><label>B:</label></div>
            </div>
            <div class="row">
              <div class="col-md-6"><input name="opa"></div>
              <div class="col-md-6"><input name="opb"></div>
            </div>
            <div class="row">
              <div class="col-md-6"><label>C:</label></div>
              <div class="col-md-6"><label>D:</label></div>
            </div>
            <div class="row">
              <div class="col-md-6"><input name="opc"></div>
              <div class="col-md-6"><input name="opd"></div>
            </div>
            <div class="row">
              <div class="col-md-3"><label>Answer: </label>
                <select name="ans" class="form-control">
                  <option value="A">A</option>
                  <option value="B">B</option>
                  <option value="C">C</option>
                  <option value="D">D</option>
                </select>
              </div>
              <div class="col-md-9"></div>

              <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-primary">Add Questions</button>
              </div>
            </div>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\ExamPortal\resources\views/questions.blade.php ENDPATH**/ ?>