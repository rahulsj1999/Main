
<?php $__env->startSection('title', 'Exam Portal | Contact'); ?>
<?php $__env->startSection('content'); ?>

<div class="container py-4">
    <h3>Contact us</h3>
    <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible">
        <button type="button" class="close" data-dismiss="alert">&times;</button>
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>
    <form id="contactForm" action="/show" method="post">
        <?php echo e(csrf_field()); ?>

        <!-- Name input -->
        <div class="mb-3">
            <label class="form-label" for="name">Name</label>
            <input class="form-control" id="name" type="text" placeholder="Name" value="<?php echo e(old('name')); ?>" name="name" data-sb-validations="required" />
            <?php if($errors->has('name')): ?>
                                      <span class="text-danger"><?php echo e($errors->first('name')); ?></span>
                                  <?php endif; ?>
        </div>
        

        <!-- Email address input -->
        <div class="mb-3">
            <label class="form-label" for="emailAddress">Email Address</label>
            <input class="form-control" id="emailAddress" type="email" name="email" value="<?php echo e(old('email')); ?>" placeholder="Email Address" data-sb-validations="required, email" />

            <?php if($errors->has('email')): ?>
                                          <span class="text-danger"><?php echo e($errors->first('email')); ?></span>
                                      <?php endif; ?>
        </div>

        <!-- Message input -->
        <div class="mb-3">
            <label class="form-label" for="message">Message</label>
            <textarea class="form-control" id="message" name='message' type="text" value="<?php echo e(old('message')); ?>" placeholder="Message" style="height: 10rem;" data-sb-validations="required"></textarea>

            <?php if($errors->has('message')): ?>
                                          <span class="text-danger"><?php echo e($errors->first('message')); ?></span>
                                      <?php endif; ?>
        </div>

        <!-- Form submit button -->
        <div class="d-grid">
            <button class="btn btn-primary btn-lg" type="submit">Submit</button>
        </div>

    </form>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\ExamPortal\resources\views/users/contact.blade.php ENDPATH**/ ?>