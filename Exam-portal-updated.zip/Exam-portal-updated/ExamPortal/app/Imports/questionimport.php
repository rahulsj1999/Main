<?php

namespace App\Imports;

use App\Models\question;
use Maatwebsite\Excel\Concerns\ToModel;

class questionimport implements ToModel
{
    /**
    * @param array $row
    *
    * @return \Illuminate\Database\Eloquent\Model|null
    */
    public function model(array $row)
    {
        
            return new question([
                'question' => $row[0],
                'a' => $row[1],
                'b' => $row[2],
                'c' => $row[3],
                'd' => $row[4],
                'ans' => $row[5]
            ]);
        
    }
}
