<?php

namespace App\Imports;

use App\Models\student;
use Maatwebsite\Excel\Concerns\ToModel;

class studentImport implements ToModel
{
    /**
    * @param array $row
    *
    * @return \Illuminate\Database\Eloquent\Model|null
    */
    public function model(array $row)
    {
        // whatever data we upload will store in $row parameter.
        return new student([
            'name' => $row[0],
            'enrollno' => $row[1],
            'mobileno' => $row[2],
            'course_name' => $row[3],
            'semester' => $row[4],
            'division' => $row[5],
            'rollno' => $row[6],
        ]);
    }
}
