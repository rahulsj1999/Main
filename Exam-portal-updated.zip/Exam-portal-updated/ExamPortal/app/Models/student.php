<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class student extends Model
{
    // $fillable = ['name', 'enrollno', 'mobileno', 'semester', 'division', 'rollno'];
    // $table = 'student';
    protected $fillable = ['name', 'enrollno', 'mobileno', 'course_name' ,'semester', 'division', 'rollno'];
    use HasFactory;
}

