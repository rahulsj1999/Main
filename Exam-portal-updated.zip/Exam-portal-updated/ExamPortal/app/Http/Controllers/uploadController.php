<?php

namespace App\Http\Controllers;

use Excel;
use Illuminate\Http\Request;
use App\Imports\studentImport;
use App\Imports\contactimport;
use App\Imports\questionimport;
use App\Exports\studentExport;
use App\Exports\contactExport;
use App\Exports\questionExport;

class uploadController extends Controller
{
    public function importStudentData(Request $request)
    {
        $path = $request->file('file')->getRealPath();
        Excel::import(new studentImport, $path);
        return redirect('/admin/students')->withSuccess("Students data imported successfully!");
    }

    public function importContactData(Request $request)
    {
        $path = $request->file('file')->getRealPath();
        Excel::import(new contactimport, $path);
        return redirect('/admin/contacts')->withSuccess("Contacts imported successfully!");
    }
    public function importQuestionData(Request $request)
    {
        $path = $request->file('file')->getRealPath();
        Excel::import(new questionimport, $path);
        return redirect('/admin/questions')->withSuccess("Questions imported successfully!");
    }

    public function exportStudentData()
    {
        return Excel::download(new studentExport, "students_record.xlsx");
    }
    public function exportQuestionData()
    {
        return Excel::download(new questionExport, "questions_record.xlsx");
    }
    public function exportContactData()
    {
        return Excel::download(new contactExport, "contacts_record.xlsx");
    }
}
