<?php

namespace App\Http\Controllers;

use App\Models\student;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Hash;
use App\Models\contact;
use Illuminate\Support\Facades\Auth;

function test_input($data)
{
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

class examcontroller extends Controller
{
    public function index()
    {
        return view("users.index");
    }
    public function about()
    {
        return view("users.about");
    }
    public function instruction()
    {
        return view("users.instruction");
    }
    public function admin_students()
    {
        $q = student::paginate(5);
        return view("admin.students")->with(['data' => $q]);
    }
    public function admin_contacts()
    {
        $q = contact::paginate(10);
        return view("admin.contacts")->with(['data' => $q]);
    }
   
    public function show(Request $request)
    {
        $request->validate([
            'name' => 'required|regex:/^[a-zA-Z]+$/u|min:3',
            'email' => 'required|email|unique:users',
            'message' => 'required',
        ]);

        $name = test_input($_POST['name']);
        $email = test_input($_POST['email']);
        $msg = test_input($_POST['message']);
        $ob = new contact();
        $ob->name = $name;
        $ob->email = $email;
        $ob->message = $msg;
        $ob->save();
        return redirect('contact')->withSuccess('Message has been sent successfully!');;
    }

    public function contact()
    {                                                                            
        return view("users.contact");
    }

    public function studentlogin()
    {
        return view("users.student_login");
    }
    public function loginUser(Request $request)
    {
        $request->validate([
            'enrollno' => 'required|regex:/^[0-9]+$/',
            'password' => 'required|min:6',
        ]);

        $user = student::where('enrollno', '=', $request->enrollno)->where('mobileno', '=', $request->password)->get();
        // return $user;
        try {
            if($user) {
                $msg = "You are Loggedin successfully " . $user[0]->name . "!";
                return view('start')->with('data',$user);
                // return $user;
            } 
           
          
          } catch (\Exception $e) {
            $msg = "Invalid crediencials!";
            return redirect('/studentlogin')->withSuccess($msg);
          }
    }
}
