<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;
use App\models\question;

class QuestionController extends Controller
{
    public function add(Request $request)
    {
        $validate=$request->validate([
            'question'=>'required',
            'opa'=>'required',
            'opb'=>'required',
            'opc'=>'required',
            'opd'=>'required',
            'ans'=>'required',
        ]);
        
        $q=new question();
        $q->question=$request->question;
        $q->a=$request->opa;
        $q->b=$request->opb;
        $q->c=$request->opc;
        $q->d=$request->opd;
        $q->ans=$request->ans;

        $q->save();
        return redirect('/questions')->withSuccess('Question successfully Added');
    }
    public function show()
    {
        // $qs = question::all();
        $qs=question::paginate(5);
        return view('admin.questions')->with(['questions'=>$qs]);
    }

    public function update(Request $request)
    {
        $validate=$request->validate([
            'question'=>'required',
            'opa'=>'required',
            'opb'=>'required',
            'opc'=>'required',
            'opd'=>'required',
            'ans'=>'required',
            'id'=>'required',
        ]);
        
        $q=question::find($request->id);
        $q->question=$request->question;
        $q->a=$request->opa;
        $q->b=$request->opb;
        $q->c=$request->opc;
        $q->d=$request->opd;
        $q->ans=$request->ans;

        $q->save();
        
        return redirect('/questions')->withSuccess('Question successfully Updated');
    }
    public function delete(Request $request)
    {
        $validate=$request->validate([
            'id'=>'required',
        ]);
        question::where('id',$request->id)->delete();
        
        return redirect('/questions')->withSuccess('Question successfully Deleted');
    }


    // start exam 
    public function startexam(Request $request)
    {
        Session::put("nextq",'1');
        Session::put("wrongans",'0');
        Session::put("correctans",'0');
        $q=question::all()->first();
        return view('answerdesk')->with(['question'=>$q]);
    }
    
    public function submitans(Request $request)
    {
        $nextq=Session::get('nextq');
        $wrongans=Session::get('wrongans');
        $correctans=Session::get('correctans');  
        $validate=$request->validate([
            'ans'=>'required',
            'dbans'=>'required',
        ]);
        $nextq+=1;
        
        if($request->dbans==$request->ans)
        {
            $correctans+=1;
        }
        else
        {
            $wrongans+=1;
        }
        Session::put("nextq",$nextq);
        Session::put("wrongans",$wrongans);
        Session::put("correctans",$correctans);

        $i=0;
        $questions=question::all(); 

        foreach($questions as $question)
        {
            $i++;
            if($questions->count() < $nextq)
            {
                return view('end');
            }

            if($i==$nextq)
            {
                return view('answerdesk')->with(['question'=>$question]);
            }
        }
    }

}