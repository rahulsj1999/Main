<?php

namespace Database\Seeders;
use Illuminate\Database\Seeder;
use Illuminate\Support\Str;
use App\Models\question;
use Illuminate\Support\Arr;
use Faker\factory as faker;

class QuestionTableseeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        
        // Using Seeding
        // $faker = Faker::create();
        // for ($i = 1; $i <= 10; $i++)
        // {
        //    $input = array("A","B","C","D");          
        //    $x = array_rand($input,1); // return index of randomely selected item
        //     question::insert([
        //         "question" => Str::random(25),
        //         "a" => Str::random(10),
        //         "b" => Str::random(10),
        //         "c" => Str::random(10),
        //         "d" => Str::random(10),
        //         "ans" => $input[$x],
        //         "created_at" => $faker->date('Y-m-d','now'),
        //         "updated_at" => $faker->date('Y-m-d','now')
        //     ]);
        // }
        
        /* Using Model Factories */
        for ($i = 1; $i <= 5; $i++)
        {
            $q = new question();
            $faker = Faker::create();
            $q->question = $faker->sentence;
            $q->a = $faker->name;
            $q->b = $faker->name;
            $q->c = $faker->name;
            $q->d = $faker->name;
            $input = array("A","B","C","D");
            $x = array_rand($input,1); // return index of randomely selected item
            $q->ans = $input[$x];
            $q->created_at = $faker->date('Y-m-d','now');
            $q->updated_at = $faker->date('Y-m-d','now');
            $q->save();
        }
    }
}