<?php
  
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Auth\AuthController;
use App\Http\Controllers\examcontroller;
use App\Http\Controllers\QuestionController;
use App\Http\Controllers\uploadController;

Route::get('login', [AuthController::class, 'index'])->name('login');
Route::post('post-login', [AuthController::class, 'postLogin'])->name('login.post'); 
Route::get('registration', [AuthController::class, 'registration'])->name('register');
Route::post('post-registration', [AuthController::class, 'postRegistration'])->name('register.post'); 
Route::get('dashboard', [AuthController::class, 'dashboard']); 
Route::get('logout', [AuthController::class, 'logout'])->name('logout');


Route::get('/', [examcontroller::class, 'index']); 
Route::get('/about', [examcontroller::class, 'about']); 

Route::get('/instruction', [examcontroller::class, 'instruction']); 
Route::get('/contact', [examcontroller::class, 'contact']); 
Route::post('/show', [examcontroller::class, 'show']); 
Route::get('/studentlogin', [examcontroller::class, 'studentlogin']); 
Route::post('login-user', [examcontroller::class, 'loginUser'])->name('login-user'); 





Route::any("answerdesk",function(){
    return view('answerdesk');
});

Route::any("/start",function(){
    return view('start');
});
Route::any("end",function(){
    return view('end');
});

Route::any('submitans',[QuestionController::class, 'submitans']);
Route::any('startexam',[QuestionController::class, 'startexam']);
Route::any('add',[QuestionController::class, 'add']);
Route::any('update',[QuestionController::class, 'update']);
Route::any('delete',[QuestionController::class, 'delete']);
Route::any('questions',[QuestionController::class, 'show']);

//------------------------------------------------------------------------
// Import and Exports
Route::get('/import_students', function() {
    return view('data_uploads.importstudentrecords');
});
Route::get('/import_contacts', function() {
    return view('data_uploads.importcontactrecords');
});
Route::get('/import_questions', function() {
    return view('data_uploads.importquestionrecords');
});


Route::post('/uploadStudentsRecord', [uploadController::class, 'importStudentData']);
Route::post('/uploadQuestionsRecord', [uploadController::class, 'importQuestionData']);
Route::post('/uploadContactsRecord', [uploadController::class, 'importContactData']);
Route::any('/exportStudentsRecord', [uploadController::class, 'exportStudentData']);
Route::any('/exportQuestionsRecord', [uploadController::class, 'exportQuestionData']);
Route::any('/exportContactsRecord', [uploadController::class, 'exportContactData']);
// -----------------------------------------------------------------------

// Admins

Route::get('/admin/students', [examcontroller::class, 'admin_students']); 
Route::get('/admin/contacts', [examcontroller::class, 'admin_contacts']); 
Route::get('/admin/questions', [examcontroller::class, 'admin_contacts']); 

